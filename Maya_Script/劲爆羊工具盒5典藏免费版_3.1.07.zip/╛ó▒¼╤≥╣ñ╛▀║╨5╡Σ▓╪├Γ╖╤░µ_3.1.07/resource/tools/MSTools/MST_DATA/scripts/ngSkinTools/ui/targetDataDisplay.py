#
#    ngSkinTools
#    Copyright (c) 2009-2017 Viktoras Makauskas.
#    All rights reserved.
#    
#    Get more information at 
#        http://www.ngskintools.com
#    
#    --------------------------------------------------------------------------
#
#    The coded instructions, statements, computer programs, and/or related
#    material (collectively the "Data") in these files are subject to the terms 
#    and conditions defined by EULA.
#         
#    A copy of EULA can be found in file 'LICENSE.txt', which is part 
#    of this source code package.
#    

from maya import cmds
from ngSkinTools.ui.layerListsUI import LayerListsUI
from ngSkinTools.ui.noLayersUI import NoLayersUI
from ngSkinTools.ui.layerDataModel import LayerDataModel
from ngSkinTools.ui.events import LayerEvents
from ngSkinTools.ui.uiWrappers import FormLayout

class TargetDataDisplay:
    '''
    Manages UI for either layer lists or "no layers available" UI
    '''
    
    def __init__(self):
        self.layersUI = LayerListsUI()
        self.noLayersUI = NoLayersUI()


    def updateUiVisibility(self):
        cmds.layout(self.noLayersUI.baseLayout,e=True,visible=self.data.layerDataAvailable==False) # 3rd option is none, hence weird compares
        cmds.layout(self.layersUI.baseLayout,e=True,visible=self.data.layerDataAvailable==True)
    
    def create(self,parent):
        self.data = LayerDataModel.getInstance()

        LayerEvents.layerAvailabilityChanged.addHandler(self.updateUiVisibility,parent)
        result = self.uiSwitchLayout = FormLayout(parent=parent)

        self.noLayersUI.createUI(self.uiSwitchLayout)
        result.attachForm(self.noLayersUI.baseLayout, 0, 0, 0, 0)
        self.layersUI.createUI(self.uiSwitchLayout)
        result.attachForm(self.layersUI.baseLayout, 0, 0, 0, 0)
        
        self.noLayersUI.update()
        self.layersUI.update()
        self.updateUiVisibility()
        
        
        return result
        
    def getSelectedInfluences(self):
        if self.data.layerDataAvailable:
            return self.layersUI.getSelectedInfluences()
        
        return []
    
