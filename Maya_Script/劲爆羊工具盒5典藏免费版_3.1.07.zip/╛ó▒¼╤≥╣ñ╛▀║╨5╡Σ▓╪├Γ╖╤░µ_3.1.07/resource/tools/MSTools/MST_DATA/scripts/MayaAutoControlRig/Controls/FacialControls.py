'''
MayaAutoControlRig.Controls.FacialControls
Handles:
    Creation of a full Facial GUI
'''
import maya.cmds as mayac
import ComboControls