#
#    ngSkinTools
#    Copyright (c) 2009-2017 Viktoras Makauskas.
#    All rights reserved.
#    
#    Get more information at 
#        http://www.ngskintools.com
#    
#    --------------------------------------------------------------------------
#
#    The coded instructions, statements, computer programs, and/or related
#    material (collectively the "Data") in these files are subject to the terms 
#    and conditions defined by EULA.
#         
#    A copy of EULA can be found in file 'LICENSE.txt', which is part 
#    of this source code package.
#    

from maya import cmds
from ngSkinTools.ui.headlessDataHost import HeadlessDataHost
from ngSkinTools.log import getLogger
from ngSkinTools.ui.events import scriptJobs
import qtCompatibility as qt
from ngSkinTools.utils import MessageException

def getMayaMainWindow():
    for widget in qt.widgets.qApp.topLevelWidgets():
        if widget.objectName()=='MayaWindow':
            return widget
    raise MessageException('QT Main window could not be detected')

class BaseQtToolWindow(qt.widgets.QWidget):
    instances = []
    
    def __init__(self,windowName,*args, **kwargs):
        super(BaseQtToolWindow, self).__init__(*args, **kwargs)
        self.windowName = windowName
        self.setParent(getMayaMainWindow())
        self.setWindowFlags(qt.QtCore.Qt.Window)   
        
        BaseQtToolWindow.instances.append(self)
        

    def closeEvent(self,event):
        BaseQtToolWindow.instances.remove(self)
        
        
    

class BaseToolWindow(object):
    log = getLogger("BaseToolWindow")
    
    windowInstances = {}
    
    def __init__(self,windowName):
        self.updateAvailable = False
        self.windowTitle = ''
        self.windowName = windowName
        self.sizeable = False
        self.menuBar = True
        
        self.defaultWidth = 300
        self.defaultHeight = 300
        self.useUserPrefSize = True
        
        BaseToolWindow.windowInstances[self.windowName]=self
        
    @staticmethod
    def closeAll():
        for _, window in BaseToolWindow.windowInstances.items():
            window.closeWindow()
        
    
    @staticmethod
    def getWindowInstance(windowName,windowClass=None):
        if BaseToolWindow.windowInstances.has_key(windowName):
            return BaseToolWindow.windowInstances[windowName]
        
        if windowClass is None:
            return None
        
        return BaseToolWindow.rebuildWindow(windowName, windowClass)
        
    @staticmethod
    def rebuildWindow(windowName,windowClass):
        BaseToolWindow.destroyWindow(windowName);
        instance = windowClass(windowName)
        instance.createWindow()
        return instance        
    
    def createWindow(self):
        self.log.debug("creating window "+self.windowName)
        if self.windowExists(self.windowName):
            raise Exception("window %s already opened" % self.windowName)
        if not self.useUserPrefSize:
            try:
                cmds.windowPref(self.windowName,remove=True)
                cmds.windowPref(self.windowName,width=self.defaultWidth,height=self.defaultHeight)
            except:
                pass

        cmds.window(self.windowName,
                                   title=self.windowTitle,
                                   maximizeButton=False,
                                   minimizeButton=False,
                                   width=self.defaultWidth,
                                   height=self.defaultHeight,
                                   sizeable=self.sizeable,
                                   menuBar=self.menuBar)
        
        
        scriptJobs.scriptJob(uiDeleted=[self.windowName,self.onWindowDeleted])
        
        HeadlessDataHost.HANDLE.addReference(self)
        
    def onWindowDeleted(self):
        if not HeadlessDataHost.HANDLE.removeReference(self):
            return

        BaseToolWindow.windowInstances.pop(self.windowName)
        
        
    def showWindow(self):
        if self.windowExists(self.windowName):
            cmds.showWindow(self.windowName)

    def closeWindow(self):
        if self.windowExists(self.windowName):
            self.onWindowDeleted()
            cmds.window(self.windowName,e=True,visible=False)

    @staticmethod        
    def windowExists(windowName):
        return cmds.window(windowName, exists=True)

    @staticmethod
    def destroyWindow(windowName):
        if BaseToolWindow.windowExists(windowName):
            instance = BaseToolWindow.getWindowInstance(windowName)
            if instance is not None:
                instance.onWindowDeleted();
            cmds.deleteUI(windowName, window=True)
            
    @staticmethod
    def closeAllWindows():
        for i in BaseToolWindow.windowInstances.values():
            i.closeWindow()
        
