'''
MayaAutoControlRig
Handles:
    Main initialization
'''
import Utils
import DJB_Character
import UI

