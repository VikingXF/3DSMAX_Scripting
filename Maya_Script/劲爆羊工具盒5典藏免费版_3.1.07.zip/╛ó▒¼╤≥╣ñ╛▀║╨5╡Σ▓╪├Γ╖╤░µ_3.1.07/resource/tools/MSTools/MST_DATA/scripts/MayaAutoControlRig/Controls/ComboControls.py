'''
MayaAutoControlRig.Controls.SimpleCurves
Handles:
    Creation of controls made of multiple curves
'''
