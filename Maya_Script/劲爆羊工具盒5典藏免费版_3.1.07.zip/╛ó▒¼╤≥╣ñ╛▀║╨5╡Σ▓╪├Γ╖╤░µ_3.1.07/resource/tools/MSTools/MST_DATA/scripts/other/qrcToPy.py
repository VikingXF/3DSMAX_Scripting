#!/usr/bin/env python
# -*- coding:UTF-8 -*-
__author__ = 'miaochenliang'

# ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
# import++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
# ↓+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
import os
import glob
import subprocess


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
def qrc_to_py(in_path):
    qrc_path, file_flag = os.path.splitext(in_path)
    print qrc_path.replace('\\', '/')
    os.system('pyrcc4 -o {0}_rc.py {0}.qrc'.format(qrc_path.replace('\\', '/')))
    # pipe = subprocess.Popen('pyrcc4 -o {0}_rc.py {0}.qrc'.format(qrc_path.replace('\\', '/')),
    #                         stdout=subprocess.PIPE, stdin=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=0x08)

if __name__ == '__main__':
    root_dir = os.path.dirname(os.getcwd())
    UI__dir_list = (os.path.join(rt, d)
                    for (rt, dr, fs) in os.walk(root_dir)
                    for d in dr if d == "UI")

    for dir_n in UI__dir_list:
        print dir_n
        filepath = '{0}/*.qrc'.format(dir_n)
        func = lambda x: qrc_to_py(x)
        map(func, glob.glob(filepath))
