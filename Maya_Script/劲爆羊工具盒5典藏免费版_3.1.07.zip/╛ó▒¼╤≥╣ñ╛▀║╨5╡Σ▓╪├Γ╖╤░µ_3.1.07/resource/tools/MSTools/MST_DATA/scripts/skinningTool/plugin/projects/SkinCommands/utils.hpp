#ifndef UTILS_HPP


#define THROWSTAT if(stat != MS::kSuccess){ stat.perror(__FILE__ + __LINE__); return stat; }


#define UTILS_HPP
#endif