# coding:utf-8


def bezier_v(p, t):
    return p[0]*(1-t)**3.0 + 3*p[1]*t*(1-t)**2 + 3*p[2]*t**2*(1-t) + p[3]*t**3


def bezier_t(p, v):
    min_t = 0.0
    max_t = 1.0
    while True:
        t = (min_t+max_t)/2.0
        error_range = bezier_v(p, t) - v
        if error_range > 0.0001:
            max_t = t
        elif error_range < -0.0001:
            min_t = t
        else:
            return t


def get_weight(x, xs, ys):
    if x <= 0.0:
        return ys[0]
    elif x >= 1.0:
        return ys[3]
    t = bezier_t(xs, x)
    return bezier_v(ys, t)


def ik_x(v, p):
    print "print v p", v, p
    return sum(v[i] * p[i] for i in range(3)) / sum(v[i] ** 2 for i in range(3))


def ik_xs(v, p, ps):
    x = ik_x(v, p)
    return [ik_x(v, p) - x for p in ps]


def ik_weights(wxs, xs, ys, r):
    return [get_weight(x / r + 0.5, xs, ys) for x in wxs]


def soft_weights(wxs, xs, ys, r):
    return [get_weight(x/r, xs, ys) for x in wxs]


def get_max_weights(weights, joint_length, vtx_length):
    return [sum([weights[joint_length*j+i] for i in range(joint_length)]) for j in range(vtx_length)]


def split_wx_matrix(vps, ps):
    return [ik_xs(v, p, ps) for v, p in vps]


def split_weights(wx_matrix, max_weights, xs, ys, r):
    weight_matrix = [[1 for _ in wx_matrix[0]]]
    for wxs in wx_matrix:
        weights = ik_weights(wxs, xs, ys, r)
        weights = [min(w1, w2) for w1, w2 in zip(weight_matrix[-1], weights)]
        weight_matrix.append(weights)
        weight_matrix[-2] = [w2 - w1 for w1, w2 in zip(weight_matrix[-1], weight_matrix[-2])]
    weight_matrix = [[w*m for w, m in zip(ws, max_weights)]for ws in weight_matrix]
    weights = sum([list(ws) for ws in zip(*weight_matrix)], [])
    return weights


def distance(p1, p2):
    return sum([(p1[i]-p2[i])**2 for i in range(3)])**0.5


def cloth_wx_matrix(vtx_points, joint_points):
    return [[distance(vtx_point, joint_point) for vtx_point in vtx_points] for joint_point in joint_points]


def cloth_weights(wx_matrix, max_weights, xs, ys, r):
    vtx_len = len(wx_matrix[0])
    joint_len = len(wx_matrix)
    weights = [get_weight(wx_matrix[joint_id][vtx_id]/r, xs, ys)
               for vtx_id in range(vtx_len)
               for joint_id in range(joint_len)]
    for vtx_id in range(vtx_len):
        vtx_weight = sum([weights[vtx_id*joint_len+joint_id] for joint_id in range(joint_len)])
        vtx_weight = max(vtx_weight, 0.000000001)
        for joint_id in range(joint_len):
            k = vtx_id*joint_len+joint_id
            weights[k] = weights[k] / vtx_weight * max_weights[vtx_id]
    return weights

























