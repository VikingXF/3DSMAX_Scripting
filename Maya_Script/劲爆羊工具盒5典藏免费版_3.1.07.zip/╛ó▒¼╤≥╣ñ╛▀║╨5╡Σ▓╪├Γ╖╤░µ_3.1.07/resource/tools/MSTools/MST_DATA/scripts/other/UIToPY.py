#!/usr/bin/env python
# -*- coding:UTF-8 -*-
__author__ = 'miaochenliang'

# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
from PyQt4.QtGui import *
from PyQt4.QtCore import *
from PyQt4 import uic
import sip
from PyQt4.QtCore import pyqtSignal as signal



from GNL.foleyUtils import scriptTool
import os
import glob


# +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ #
def uicToPY(name):
    print 'file_path ---- >>> %s' % name
    with open(str(name).replace('.ui', '.py'), 'w') as f:
        uic.compileUi(name, f)


if __name__ == '__main__':
    root_dir = os.path.dirname(scriptTool.getScriptPath()).replace('\\', '/')
    print(root_dir )
    UI__dir_list = (os.path.join(rt, d)
                    for (rt, dr, fs) in os.walk(root_dir)
                    for d in dr if d == "UI")

    for dir_n in UI__dir_list:
        filepath = '{0}/*.ui'.format(dir_n)
        func = lambda x: uicToPY(x)
        map(func, glob.glob(filepath))
