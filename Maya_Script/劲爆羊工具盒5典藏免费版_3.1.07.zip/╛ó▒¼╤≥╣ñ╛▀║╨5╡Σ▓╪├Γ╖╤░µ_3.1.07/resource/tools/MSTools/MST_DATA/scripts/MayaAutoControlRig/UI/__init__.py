'''
MayaAutoControlRig.UI
Handles:
    UI
'''
import Main_UI
import Version_Info
import AssortedFunctions