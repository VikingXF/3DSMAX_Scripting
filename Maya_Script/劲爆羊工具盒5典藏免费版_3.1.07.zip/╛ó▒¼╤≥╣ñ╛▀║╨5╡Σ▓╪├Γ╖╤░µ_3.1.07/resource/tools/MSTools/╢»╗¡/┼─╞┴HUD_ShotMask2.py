from zshotmask_ui import ZShotMask, ZShotMaskUi
global ZShotMask
global ZShotMaskUi
ZShotMaskUi.display()