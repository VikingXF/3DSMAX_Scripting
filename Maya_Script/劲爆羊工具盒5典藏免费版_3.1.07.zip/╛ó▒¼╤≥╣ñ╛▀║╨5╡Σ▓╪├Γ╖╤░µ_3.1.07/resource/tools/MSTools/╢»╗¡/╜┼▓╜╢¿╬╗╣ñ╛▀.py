import rjAnchorTransform.ui 
rjAnchorTransform.ui.show()