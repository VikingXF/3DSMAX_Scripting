import JUM.spiral as spiral
spiral.run()