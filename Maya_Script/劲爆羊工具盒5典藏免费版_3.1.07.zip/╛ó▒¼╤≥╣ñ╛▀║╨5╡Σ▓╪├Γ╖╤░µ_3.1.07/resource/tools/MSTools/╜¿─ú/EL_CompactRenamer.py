import EL_CompactRenamer as ELComRen
ELComRen.MainClassCompactRen()