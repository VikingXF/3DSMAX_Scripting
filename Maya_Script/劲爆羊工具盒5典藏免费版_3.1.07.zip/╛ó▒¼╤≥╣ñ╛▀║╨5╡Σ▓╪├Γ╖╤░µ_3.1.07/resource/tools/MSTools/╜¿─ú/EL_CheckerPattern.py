import EL_CheckerPattern as ELCP
reload(ELCP)
ELCP.MainClassElCheckerPattern()