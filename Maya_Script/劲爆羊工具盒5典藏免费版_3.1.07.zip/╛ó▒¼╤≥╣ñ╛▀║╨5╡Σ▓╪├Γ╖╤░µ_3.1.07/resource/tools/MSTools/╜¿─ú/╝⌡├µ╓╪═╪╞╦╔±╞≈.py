import QuadRemesher
qr = QuadRemesher.QuadRemesher()