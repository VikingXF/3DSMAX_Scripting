import maya.cmds
maya.cmds.loadPlugin("wire.py")