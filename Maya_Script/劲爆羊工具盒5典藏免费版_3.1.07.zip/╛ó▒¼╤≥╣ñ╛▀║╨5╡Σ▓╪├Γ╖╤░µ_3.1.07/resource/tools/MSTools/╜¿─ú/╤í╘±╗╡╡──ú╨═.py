import SelectBadGeo as BG
MCBG = BG.MainClassBadGeo()
MCBG.badGeoUI()


