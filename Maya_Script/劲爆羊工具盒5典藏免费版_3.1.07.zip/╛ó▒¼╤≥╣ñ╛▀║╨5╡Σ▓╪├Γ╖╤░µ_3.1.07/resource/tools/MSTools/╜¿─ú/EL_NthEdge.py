import EL_NthEdge as ELNthE
ELNthE.MainClassElNthEdge()