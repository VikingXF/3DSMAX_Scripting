import attrManager
atm = attrManager.attrManager()

