from skinningTool import SkinningToolsUI
SkinningToolsUI.startUI()