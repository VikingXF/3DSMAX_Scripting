import rigtools.variableKinematics as vk
vk.build_ui()