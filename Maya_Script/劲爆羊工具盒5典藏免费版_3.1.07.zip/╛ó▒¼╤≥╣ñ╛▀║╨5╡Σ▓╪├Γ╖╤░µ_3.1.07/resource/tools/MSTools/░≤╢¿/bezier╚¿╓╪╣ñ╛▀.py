from weights import ui
ui.show()