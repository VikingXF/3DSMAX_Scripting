import skirtRig
reload(skirtRig)
skirtRig.show()