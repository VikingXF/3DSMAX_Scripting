'''This script can be used as your shelf button.
To use: Move the whole module (MayaAutoControlRig folder) to your scripts directory and run this script.
'''

#import sys 
#sys.path.append( 'C:\\CustomSciptPath' )

import MayaAutoControlRig
MayaAutoControlRig.UI.Main_UI.MIXAMO_AutoControlRig_UI()